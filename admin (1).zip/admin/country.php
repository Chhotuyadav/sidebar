    <!-- ////////////////////////////////////// Header //////////////////////////////////////-->
	<?php $this->load->view('common/header')?>

    <!-- /////////////////////////////////////// Sidebar /////////////////////////////////////-->
	<?php $this->load->view('common/sidebar')?>

    <!-- ////////////////////////////////////// Main Content //////////////////////////////////////-->



<div class="app-content content">
   <div class="content-wrapper">
	      	<div class="content-header row">
				<div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
					<h3 class="content-header-title mb-0 d-inline-block">Country List</h3>
					<div class="row breadcrumbs-top d-inline-block">
						<div class="breadcrumb-wrapper col-12">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?= base_url('/')?>">Home</a>
								</li>
								<li class="breadcrumb-item"><a href="<?= base_url('country-list')?>">All Country</a>
								</li>
								
							</ol>
						</div>
					</div>
				</div>
			</div>
				
	    <div class="content-body">
	        <form action="<?= base_url('country-list')?>" method="post">
    	        <div class="row">
    	           <div class="col-md-6">
    	               <div class="form-group">
    	                    <label>Country Name</label>
    	                    <input type="text" name="country" class="form-control">
    	               </div>
    	           </div>
    	           <div class="col-md-6 text-center align-items-center justify-content-center d-flex">
    	               <button type="submit" class="btn btn-success">Submit</button>
    	           </div>
    	        </div>
    	   </form>
	      	<div class="table-responsive">
                    <table id="dataTable" class="table">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Country Name</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($result as $key => $val):?>
                            <tr>
                              <th scope="row"><?= $key+1?></th>
                              <td>
                                  <p class="countname"><?= $val['countryname']?></p>
                                  <form action="<?= base_url('admin/update_countryName')?>" method="POST" class="d-none updtform">  
                                        <input type="hidden" value="<?= $val['countryid']?>" name="id">
                                        <input class="form-control form-control-sm" name="country" value="<?= $val['countryname']?>">
                                        <button type="submit" class="btn btn-sm btn-success">Update</button>
                                  </form>
                              </td>
                              <td>
                                <div class="btn-group" role="group" aria-label="Action">
                                    <button type="button" class="btn btn-primary edit-action">Edit</button>
                                    <a href="<?= base_url('country-del/').$val['countryid']?>" class="btn btn-danger">Delete</a>
                                </div>
                              </td>
                            </tr>
                        <?php endforeach;?>
                      </tbody>
                    </table>
                </div>
	    </div>
   </div>
</div>
    

    

    <!-- ////////////////////////////////////// Footer //////////////////////////////////////-->
    <?php $this->load->view('common/footer')?>
    
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ],
                 lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, 'All'],
                ],
                // order: [[1, 'desc']],
            } );
        } );
        
        
        $('body').on('click','.edit-action',function(){
            $('.countname').removeClass('d-none')
            $('form.updtform').addClass('d-none')
            $(this).parents('tr').find('form.updtform').parent().find('.countname').addClass('d-none')
            $(this).parents('tr').find('form.updtform').removeClass('d-none')
        })
    </script>

  </body>

</html>