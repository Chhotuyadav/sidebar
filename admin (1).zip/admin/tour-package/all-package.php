    <!-- ////////////////////////////////////// Header //////////////////////////////////////-->
	<?php $this->load->view('common/header')?>

    <!-- /////////////////////////////////////// Sidebar /////////////////////////////////////-->
	<?php $this->load->view('common/sidebar')?>

    <!-- ////////////////////////////////////// Main Content //////////////////////////////////////-->



   <div class="app-content content">
	   <div class="content-wrapper">
	      	<div class="content-header row">
				<div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
					<h3 class="content-header-title mb-0 d-inline-block">All Package</h3>
					<div class="row breadcrumbs-top d-inline-block">
						<div class="breadcrumb-wrapper col-12">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?= base_url('/')?>">Home</a>
								</li>
								<li class="breadcrumb-item"><a href="<?= base_url('add-package')?>">Add Package</a>
								</li>
								<li class="breadcrumb-item active">All Package
								</li>
							</ol>
						</div>
					</div>
				</div>
			</div>

	      <div class="content-body">
	      	
	      </div>
	   </div>
	</div>
    

    

    <!-- ////////////////////////////////////// Footer //////////////////////////////////////-->
    <?php $this->load->view('common/footer')?>

    

    
  </body>

</html>