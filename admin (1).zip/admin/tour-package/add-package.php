    <!-- ////////////////////////////////////// Header //////////////////////////////////////-->

	<?php $this->load->view('common/header')?>



    <!-- /////////////////////////////////////// Sidebar /////////////////////////////////////-->

	<?php $this->load->view('common/sidebar')?>



    <!-- ////////////////////////////////////// Main Content //////////////////////////////////////-->







   <div class="app-content content">

	   <div class="content-wrapper">

	      <div class="content-header row">

				<div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">

					<h3 class="content-header-title mb-0 d-inline-block">Add Package</h3>

					<div class="row breadcrumbs-top d-inline-block">

						<div class="breadcrumb-wrapper col-12">

							<ol class="breadcrumb">

								<li class="breadcrumb-item"><a href="<?= base_url('/')?>">Home</a>

								</li>

								<li class="breadcrumb-item"><a href="<?= base_url('all-package')?>">All Package</a>

								</li>

								<li class="breadcrumb-item active">Add Package

								</li>

							</ol>

						</div>

					</div>

				</div>

			</div>

				

	      <div class="content-body">
	          <form class="add-pakage">

	      	    <div class="row">

	                <div class="col-md-6">
	      	            <div class="form-group">
									<label for="userinput5">Title *</label>
									<input class="form-control border-primary" name="title">
								</div>
	      	        </div>

	      	        

	      	        <div class="col-md-6">
	      	            <div class="form-group">
									<label>Image thumb *</label>
									<input class="form-control border-primary" type="file" name="img_thumb">
								</div>
	      	        </div>

	      	        <div class="col-md-12">
	      	            <div class="form-group">
											<label>Image </label>
											<div class="repeater">
											    <div data-repeater-list="outer-list">
											      <div data-repeater-item class="row p-1">
											        <input type="file" name="image[]" class="form-control border-primary col-10" />
											        <input data-repeater-delete type="button" value="Delete" class="col-2 btn btn-danger" />
											      </div>
											    </div>
											    <input data-repeater-create type="button" class="btn btn-primary" value="Add"/>
											</div>
								</div>
	      	        </div>
	      	    
	      	        
	      	        <div class="col-md-6">
	      	            <div class="form-group">
									<label for="userinput5">Latitude *</label>
									<input class="form-control border-primary" name="latitude">
								</div>
	      	        </div>

							<div class="col-md-6">
	      	            <div class="form-group">
									<label for="userinput5">Longitude *</label>
									<input class="form-control border-primary" name="longitude">
								</div>
	      	        </div>	      	        




	      	        <div class="col-md-12">
	      	            <div class="form-group">
									<label for="userinput5">Address *</label>
									<textarea class="form-control" name="address"></textarea>
								</div>
	      	        </div>

	      	        <div class="col-md-6">
	      	            <div class="form-group">
									<label for="userinput5">Duration *</label>
									<input class="form-control border-primary" name="duration">
								</div>

	      	        </div>

	      	        

	      	        <div class="col-md-6">
	      	            <div class="form-group">
									<label for="userinput5">Guid Language</label>
									<input class="form-control border-primary" name="guid-language">
								</div>
	      	        </div>


	      	        <div class="col-md-12">
	      	            <h3>Tour Overview Description</h3>
	      	            <textarea id="summernote1" name="overview-tour"></textarea>
	      	        </div>

	      	        <div class="col-md-12">
	      	            <h3>What's Included</h3>
	      	            <textarea id="summernote2" name="highlight-tour"></textarea>
	      	        </div>


	      	        <div class="col-md-12">
	      	            <div class="form-group">
									<label >Important Note *</label>
									<textarea class="form-control" name="impotnant-note"></textarea>
								</div>
	      	        </div>

	      	        <div class="col-md-12">
	      	            <h3>Additional Information</h3>
	      	            <textarea id="summernote3" name="itinerary"></textarea>
	      	        </div>

	      	        
	      	        <div class="col-md-6">
	      	            <div class="form-group">
									<label >Adult price*</label>
									<input class="form-control border-primary" type="number" name="adult-price">
								</div>
	      	        </div>

	      	        <div class="col-md-6">
	      	            <div class="form-group">
									<label >Child price*</label>
									<input class="form-control border-primary" type="number" name="child-price">
								</div>
	      	        </div>

	      	        
	      	        <div class="col-md-12">
	      	            <button type="submit" class="btn-primary btn btn-lg btn-block">Submit</button>
	      	        </div>
	      	    </div>

	          </form>

	      </div>

	   </div>

	</div>

    <!-- ////////////////////////////////////// Footer //////////////////////////////////////-->



    <?php $this->load->view('common/footer')?>

    <script src="<?= base_url('includes/js/script.js')?>"></script>
    <script type="text/javascript">
    	$('body').on('submit','.add-pakage',function(e){
    		e.preventDefault(this)
    		var title = $(this).find('input[name=title]').val();
    		var latitude = $(this).find('input[name=latitude]').val();
    		var longitude = $(this).find('input[name=longitude]').val();
    		var address = $(this).find('textarea[name=address]').val();
    		var duration = $(this).find('input[name=duration]').val();
    		var guidLan = $(this).find('input[name=guid-language]').val();

    		var desc = $(this).find('textarea[name=overview-tour]').val();
    		var whatsIncluded = $(this).find('textarea[name=highlight-tour]').val();
    		var impotnant = $(this).find('textarea[name=impotnant-note]').val();
    		var addiInfo = $(this).find('textarea[name=itinerary]').val();

    		var adult = $(this).find('input[name=adult-price]').val();
    		var child = $(this).find('input[name=child-price]').val();

    		if(title == ''){
    			return showMsg('danger','Please Enter Title');
    		}

    		if(latitude == ''){
    			return showMsg('danger','Please Enter Latitude ');
    		}

    		if(longitude == ''){
    			return showMsg('danger','Please Enter Longitude');
    		}

    		if(address == ''){
    			return showMsg('danger','Please Enter Address');
    		}

    		if(duration == ''){
    			return showMsg('danger','Please Enter Duration');
    		}

    		if(desc == ''){
    			return showMsg('danger','Please Enter Overview Description');
    		}

    		if(whatsIncluded == ''){
    			return showMsg('danger',"Please Enter What's Included");
    		}


    		if(impotnant == ''){
    			return showMsg('danger','Please Enter important note');
    		}

    		if(addiInfo == ''){
    			return showMsg('danger','Please Enter Additional Information');
    		}

    		if(adult == ''){
    			return showMsg('danger','Please Enter Adult Price');
    		}

    		if(child == ''){
    			return showMsg('danger','Please Enter Child Price');
    		}

    		var formData = new FormData(this);

    		var res = insertData("<?= base_url('admin/insertPackage')?>",'POST',formData)
    		console.log(res)


    	})	
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.min.js"></script>

    <script>

      $('#summernote1').summernote({

        placeholder: 'Tour overview',

        tabsize: 2,

        height: 100

      });

      $('#summernote2').summernote({

        placeholder: 'Tour highlight',

        tabsize: 2,

        height: 100

      });

      $('#summernote3').summernote({

        placeholder: 'Itinerary',

        tabsize: 2,

        height: 100

      });

      $('#summernote4').summernote({

        placeholder: 'Inclusion',

        tabsize: 2,

        height: 100

      });

      $('#summernote5').summernote({

        placeholder: 'Detail',

        tabsize: 2,

        height: 100

      });

	    $(document).ready(function () {
	        $('.repeater').repeater({
	            // (Required if there is a nested repeater)
	            // Specify the configuration of the nested repeaters.
	            // Nested configuration follows the same format as the base configuration,
	            // supporting options "defaultValues", "show", "hide", etc.
	            // Nested repeaters additionally require a "selector" field.
	            repeaters: [{
	                // (Required)
	                // Specify the jQuery selector for this nested repeater
	                selector: '.inner-repeater'
	            }]
	        });
	    });      

    </script>

    

  </body>



</html>