    <!-- ////////////////////////////////////// Header //////////////////////////////////////-->
	<?php $this->load->view('common/header')?>

    <!-- /////////////////////////////////////// Sidebar /////////////////////////////////////-->
	<?php $this->load->view('common/sidebar')?>

    <!-- ////////////////////////////////////// Main Content //////////////////////////////////////-->



<div class="app-content content">
   <div class="content-wrapper">
	      	<div class="content-header row">
				<div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
					<h3 class="content-header-title mb-0 d-inline-block">Province List</h3>
					<div class="row breadcrumbs-top d-inline-block">
						<div class="breadcrumb-wrapper col-12">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?= base_url('/')?>">Home</a>
								</li>
								<li class="breadcrumb-item"><a href="<?= base_url('province')?>">All Province</a>
								</li>
								
							</ol>
						</div>
					</div>
				</div>
			</div>
				
	    <div class="content-body">
	      	<div class="table-responsive">
	        <div class="col-md-12 m-5">
	            <button class="btn btn-lg btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">+ Add</button>
	        </div>
                    <table id="dataTable" class="table">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Name</th>
                          <th scope="col">Image</th>
                          <th scope="col">Description</th>
                          <th scope="col">Title</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($result as $key => $val):?>
                            <tr>
                              <th scope="row"><?= $key+1?></th>
                              <td><?= $val['name']?></td>
                              <td><img width="10%" src="<?= base_url('uploads/')?><?= $val['image']?>"></td>
                              <td><?= $val['desc']?></td>
                              <td><?= $val['title']?></td>
                            </tr>
                        <?php endforeach;?>
                      </tbody>
                    </table>
                </div>
	    </div>
   </div>
</div>
    


<!-- Large modal -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Province</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?= base_url('province')?>" method="POST" enctype="multipart/form-data">                
            <div class="modal-body">
                  <div class="form-group">
                    <label for="Transfer-Province-Name" class="col-form-label">Transfer Province Name:</label>
                    <input type="text" class="form-control" name="Transfer-Province-Name" id="Transfer-Province-Name">
                  </div>
                  <div class="form-group">
                    <label for="image" class="col-form-label">Image:</label>
                    <input type="file" name="image" id="image" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="Package-Transfer-Title" class="col-form-label">Package Transfer Title:</label>
                    <input type="text" class="form-control" name="Package-Transfer-Title" id="Package-Transfer-Title">
                  </div>
                  <div class="form-group">
                    <label for="message-text" class="col-form-label">Transfer Description:</label>
                    <textarea class="form-control" name="Transfer-Description" id="message-text"></textarea>
                  </div>
            </div>
                
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Send message</button>
            </div>
        </form>
    </div>
  </div>
</div>
    

    <!-- ////////////////////////////////////// Footer //////////////////////////////////////-->
    <?php $this->load->view('common/footer')?>
    
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ],
                 lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, 'All'],
                ],
                // order: [[1, 'desc']],
            } );
        } );
        
        
        $('body').on('click','.edit-action',function(){
            $('.countname').removeClass('d-none')
            $('form.updtform').addClass('d-none')
            $(this).parents('tr').find('form.updtform').parent().find('.countname').addClass('d-none')
            $(this).parents('tr').find('form.updtform').removeClass('d-none')
        })
    </script>

  </body>

</html>