<div class="main-menu menu-fixed menu-dark menu-accordion    menu-shadow " data-scroll-to-active="true">
   <div class="main-menu-content">
      <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">

         <li class=" nav-item">
            <a href="<?= base_url('/')?>">
               <i class="icon-home"></i>
               <span class="menu-title" data-i18n="nav.dash.main">Dashboard</span>
            </a>
         </li>

         <li class=" nav-item">
            <a href="javascript:void(0);">
               <i class="icon-layers"></i>
               <span class="menu-title" data-i18n="nav.dash.main">Tour Package</span>
               <span class="badge badge badge-info badge-pill float-right mr-2">2</span>
            </a>
            <ul class="menu-content">
               <li>
                  <a class="menu-item" href="<?= base_url('add-package')?>" data-i18n="nav.dash.ecommerce">
                        Add Tour Package
                  </a>
               </li>
               <li>
                  <a class="menu-item" href="<?= base_url('all-package')?>" data-i18n="nav.dash.project">
                     All Tour Package
                  </a>
               </li>
            </ul>
         </li>
         

         <li class=" nav-item">
            <a href="<?= base_url('/country-list')?>">
               <i class="icon-globe"></i>
               <span class="menu-title" data-i18n="nav.dash.main">Country</span>
            </a>
         </li>
         

         <li class=" nav-item">
            <a href="<?= base_url('/province')?>">
               <i class="ft-cloud"></i>
               <span class="menu-title" data-i18n="nav.dash.main">Province</span>
            </a>
         </li>
         
      </ul>
   </div>
</div>